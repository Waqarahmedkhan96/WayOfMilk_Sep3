namespace Entities;

public class Cow
{
    public int Id { get; set; }
    public DateOnly BirthDate { get; set; }
}
