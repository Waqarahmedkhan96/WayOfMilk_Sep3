namespace Entities;

public class Container
{
    public int Id { get; set; }
    public double CapacityL { get; set; }
}
